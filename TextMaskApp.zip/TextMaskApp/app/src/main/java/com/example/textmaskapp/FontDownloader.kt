package com.example.textmaskapp

import android.content.Context
import android.graphics.Typeface
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.URL

object FontDownloader {

    private const val TAG = "FontDownloader"
    private const val API_KEY = "AIzaSyDh1D6_RUXoHxk8Tj3lxGJ8kPkdL96W9pI"
    private const val API_URL = "https://www.googleapis.com/webfonts/v1/webfonts?key=$API_KEY"

    private fun styleKey(style: FontStyle): String = when (style) {
        FontStyle.REGULAR -> "regular"
        FontStyle.ITALIC -> "italic"
        FontStyle.BOLD -> "700"
        FontStyle.THIN -> "100"
    }

    private fun cacheFile(context: Context, family: String, style: FontStyle): File {
        val cacheDir = File(context.filesDir, "font_cache")
        if (!cacheDir.exists()) cacheDir.mkdirs()
        return File(cacheDir, "${family}_${style.name}.ttf".replace(" ", "_"))
    }

    suspend fun getGoogleFont(
        context: Context,
        family: String,
        requestedStyle: FontStyle
    ): Typeface = withContext(Dispatchers.IO) {
        try {
            val json = JSONObject(URL(API_URL).readText())
            val items = json.getJSONArray("items")
            var fontItem: JSONObject? = null
            for (i in 0 until items.length()) {
                val item = items.getJSONObject(i)
                if (item.getString("family").equals(family, true)) {
                    fontItem = item
                    break
                }
            }
            if (fontItem == null) {
                Log.w(TAG, "Font not found: $family → Roboto")
                return@withContext Typeface.DEFAULT
            }
            val files = fontItem.getJSONObject("files")
            val resolvedStyle = if (files.has(styleKey(requestedStyle))) requestedStyle else FontStyle.REGULAR
            val key = styleKey(resolvedStyle)
            val url = files.optString(key, null) ?: return@withContext Typeface.DEFAULT

            val outFile = cacheFile(context, family, resolvedStyle)
            if (!outFile.exists()) {
                URL(url).openStream().use { input ->
                    outFile.outputStream().use { output ->
                        input.copyTo(output)
                    }
                }
            }

            Typeface.createFromFile(outFile)
        } catch (e: Exception) {
            Log.e(TAG, "Font load failed → Roboto", e)
            Typeface.DEFAULT
        }
    }

    suspend fun getTypeface(context: Context, family: String, style: FontStyle): Typeface {
        return getGoogleFont(context, family, style)
    }
}
