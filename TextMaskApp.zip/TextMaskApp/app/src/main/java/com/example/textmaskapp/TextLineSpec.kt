package com.example.textmaskapp

enum class FontStyle {
    REGULAR,
    ITALIC,
    BOLD,
    THIN
}

data class TextLineSpec(
    val text: String,
    val bbox: List<Pair<Int, Int>>,  // Quad
    val googleFontName: String,
    val fontSizePx: Float,
    val color: Int = 0xFFFFFFFF.toInt(),
    val style: FontStyle = FontStyle.REGULAR
)
