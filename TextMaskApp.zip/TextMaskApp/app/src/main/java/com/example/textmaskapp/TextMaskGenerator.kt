package com.example.textmaskapp

import android.content.Context
import android.graphics.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

object TextMaskGenerator {

    suspend fun generateMultiLineMask(
        context: Context,
        textSpecs: List<TextLineSpec>,
        outputName: String,
        outputWidth: Int,
        outputHeight: Int,
        originalWidth: Int,
        originalHeight: Int
    ): File = withContext(Dispatchers.IO) {

        val bitmap = Bitmap.createBitmap(outputWidth, outputHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)

        val scaleX = outputWidth.toFloat() / originalWidth
        val scaleY = outputHeight.toFloat() / originalHeight

        for (spec in textSpecs) {
            drawSingleTextLine(context, canvas, spec, scaleX, scaleY)
        }

        val outFile = File(context.filesDir, outputName)
        outFile.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }

        outFile
    }

    private suspend fun drawSingleTextLine(
        context: Context,
        canvas: Canvas,
        spec: TextLineSpec,
        scaleX: Float,
        scaleY: Float
    ) {
        val typeface = FontDownloader.getTypeface(context, spec.googleFontName, spec.style)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = spec.color
            textAlign = Paint.Align.LEFT
            this.typeface = typeface
            textSize = spec.fontSizePx * ((scaleX + scaleY) / 2f)
        }

        val left = spec.bbox.minOf { it.first } * scaleX
        val right = spec.bbox.maxOf { it.first } * scaleX
        val top = spec.bbox.minOf { it.second } * scaleY
        val bottom = spec.bbox.maxOf { it.second } * scaleY

        val boxWidth = right - left

        // Scale width only if text too long; no height shrinking
        val measuredWidth = paint.measureText(spec.text)
        if (measuredWidth > boxWidth) {
            paint.textSize *= boxWidth / measuredWidth
        }

        val metrics = paint.fontMetrics
        val textHeight = metrics.descent - metrics.ascent
        val y = top + (bottom - top - textHeight) / 2f - metrics.ascent

        canvas.drawText(spec.text, left, y, paint)
    }

    suspend fun overlayMaskOnImage(
        context: Context,
        baseImageFile: File,
        textSpecs: List<TextLineSpec>,
        outputFile: File,
        targetWidth: Int,
        targetHeight: Int,
        originalWidth: Int,
        originalHeight: Int
    ): File = withContext(Dispatchers.IO) {

        // Load and resize base image
        val baseBitmap = BitmapFactory.decodeFile(baseImageFile.absolutePath)
            ?: throw Exception("Base image not found")
        val scaledBase = Bitmap.createScaledBitmap(baseBitmap, targetWidth, targetHeight, true)

        // Generate mask in memory (temporary)
        val maskBitmap = generateMultiLineMask(
            context,
            textSpecs,
            "temp_mask.png",
            targetWidth,
            targetHeight,
            originalWidth,
            originalHeight
        ).let { BitmapFactory.decodeFile(it.absolutePath)!! }

        // Create combined bitmap
        val combinedBitmap = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(combinedBitmap)
        canvas.drawBitmap(scaledBase, 0f, 0f, null) // base first
        canvas.drawBitmap(maskBitmap, 0f, 0f, null) // mask overlay

        // Save final combined image
        outputFile.outputStream().use { combinedBitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }

        outputFile
    }
}
