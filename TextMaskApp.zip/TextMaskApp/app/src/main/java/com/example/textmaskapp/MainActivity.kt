package com.example.textmaskapp

import android.graphics.BitmapFactory
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import androidx.activity.ComponentActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import android.graphics.Bitmap

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val black = 0xFF000000.toInt()

        val textBlocks = listOf(
            TextLineSpec("DO", listOf(371 to 85, 419 to 85, 419 to 125, 371 to 125), "Engagement", 40f, black, FontStyle.ITALIC),
            TextLineSpec("something nice", listOf(214 to 121, 420 to 121, 420 to 180, 214 to 180), "Engagement", 49f, black, FontStyle.ITALIC),
            TextLineSpec("for someone else", listOf(187 to 176, 418 to 176, 418 to 203, 187 to 203), "Engagement", 49f, black, FontStyle.ITALIC),
            TextLineSpec("and", listOf(363 to 204, 419 to 204, 419 to 242, 363 to 242), "Engagement", 49f, black, FontStyle.ITALIC),
            TextLineSpec("DON'T", listOf(323 to 243, 423 to 243, 423 to 286, 323 to 286), "Engagement", 40f, black, FontStyle.ITALIC),
            TextLineSpec("tell anyone", listOf(263 to 279, 422 to 279, 422 to 344, 263 to 344), "Engagement", 49f, black, FontStyle.ITALIC),
            TextLineSpec("about it", listOf(308 to 316, 421 to 316, 421 to 369, 308 to 369), "Engagement", 49f, black, FontStyle.ITALIC)
        )

        val targetWidth = 612
        val targetHeight = 460

        CoroutineScope(Dispatchers.Main).launch {
            try {
                // Save base image in internal filesDir
                val baseBitmap = BitmapFactory.decodeResource(resources, R.drawable.quote_base)
                val baseFile = File(filesDir, "temp_base.png")
                baseFile.outputStream().use { baseBitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }

                // Save final combined image in same filesDir
                val outFile = File(filesDir, "quote_final.png")

                // Overlay mask on base image
                val combinedFile = TextMaskGenerator.overlayMaskOnImage(
                    context = this@MainActivity,
                    baseImageFile = baseFile,
                    textSpecs = textBlocks,
                    outputFile = outFile,
                    targetWidth = targetWidth,
                    targetHeight = targetHeight,
                    originalWidth = targetWidth,
                    originalHeight = targetHeight
                )

                Log.d("COMBINED_FILE", "Saved at: ${combinedFile.absolutePath}")

                val resultBitmap = BitmapFactory.decodeFile(combinedFile.absolutePath)
                findViewById<ImageView>(R.id.previewImage).setImageBitmap(resultBitmap)

            } catch (e: Exception) {
                Log.e("MAIN_ERROR", "Failed to generate overlay", e)
            }
        }
    }
}
