package com.example.textmaskapp

import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.widget.ImageView
import androidx.activity.ComponentActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // === Text blocks from your JSON ===
        val textBlocks = listOf(
            TextLineSpec("BE SOMEBODY", listOf(76 to 193, 398 to 193, 398 to 272, 76 to 272), "Bebas Neue", 60f),
            TextLineSpec("WHO MAKES", listOf(81 to 277, 357 to 277, 357 to 341, 81 to 341), "Bebas Neue", 60f),
            TextLineSpec("EVERYBODY FEEL", listOf(79 to 349, 458 to 349, 458 to 413, 79 to 413), "Bebas Neue", 60f),
            TextLineSpec("LIKE A", listOf(77 to 421, 229 to 421, 229 to 485, 77 to 485), "Bebas Neue", 60f),
            TextLineSpec(" SOMEBODY.", listOf(82 to 492, 332 to 492, 332 to 557, 82 to 557), "Bebas Neue", 57f)
        )

        val originalWidth = 500
        val originalHeight = 748

        CoroutineScope(Dispatchers.Main).launch {
            try {
                // Save mask to external files directory (PC-accessible)
                val externalDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
                if (externalDir != null && !externalDir.exists()) externalDir.mkdirs()

                val outFile = File(externalDir, "quote_mask.png")

                val bitmapFile = TextMaskGenerator.generateMultiLineMask(
                    context = this@MainActivity,
                    textSpecs = textBlocks,
                    outputName = outFile.name, // filename
                    outputWidth = originalWidth,
                    outputHeight = originalHeight,
                    originalWidth = originalWidth,
                    originalHeight = originalHeight
                )

                Log.d("MASK_FILE", "Saved mask at: ${bitmapFile.absolutePath}")

                // Display in ImageView
                val bitmap = BitmapFactory.decodeFile(bitmapFile.absolutePath)
                findViewById<ImageView>(R.id.previewImage).setImageBitmap(bitmap)

            } catch (e: Exception) {
                Log.e("MASK_ERROR", "Failed to generate mask", e)
            }
        }
    }
}
