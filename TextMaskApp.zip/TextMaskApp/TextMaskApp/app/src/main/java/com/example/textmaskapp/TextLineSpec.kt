package com.example.textmaskapp

data class TextLineSpec(
    val text: String,
    val bbox: List<Pair<Int, Int>>,  // Quad coordinates
    val googleFontName: String,
    val fontSizePx: Float,
    val color: Int = 0xFFFFFFFF.toInt() // default white
)
