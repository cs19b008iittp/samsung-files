package com.example.textmaskapp

import android.content.Context
import android.graphics.Typeface
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

object FontDownloader {

    private const val API_KEY = "YOUR_API_KEY_HERE" // ← Put your Google Fonts API key here
    private const val API_URL = "https://www.googleapis.com/webfonts/v1/webfonts?key=$API_KEY"

    // Call this from a coroutine or background thread
    suspend fun getGoogleFont(context: Context, fontName: String): Typeface =
        withContext(Dispatchers.IO) {

            val cacheDir = File(context.filesDir, "font_cache")
            if (!cacheDir.exists()) cacheDir.mkdirs()

            val safeName = fontName.replace(" ", "_")
            val ttfFile = File(cacheDir, "$safeName.ttf")

            // Already cached?
            if (ttfFile.exists()) {
                return@withContext Typeface.createFromFile(ttfFile)
            }

            // Fetch Google Fonts JSON
            val jsonString = URL(API_URL).readText()
            val json = JSONObject(jsonString)
            val items = json.getJSONArray("items")

            var fontUrl: String? = null
            for (i in 0 until items.length()) {
                val item = items.getJSONObject(i)
                if (item.getString("family").equals(fontName, ignoreCase = true)) {
                    val files = item.getJSONObject("files")
                    fontUrl = files.optString("regular", null) // use 'regular' style
                    break
                }
            }

            if (fontUrl == null) {
                Log.e("FontDownloader", "Font not found in API: $fontName")
                return@withContext Typeface.DEFAULT
            }

            // Download TTF
            try {
                val url = URL(fontUrl)
                url.openStream().use { input ->
                    ttfFile.outputStream().use { output ->
                        input.copyTo(output)
                    }
                }
            } catch (e: Exception) {
                Log.e("FontDownloader", "Failed downloading font: $fontName", e)
                return@withContext Typeface.DEFAULT
            }

            return@withContext Typeface.createFromFile(ttfFile)
        }
}
