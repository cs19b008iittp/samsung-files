package com.example.textmaskapp

import android.content.Context
import android.graphics.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

object TextMaskGenerator {

    suspend fun generateMultiLineMask(
        context: Context,
        textSpecs: List<TextLineSpec>,
        outputName: String,
        outputWidth: Int,
        outputHeight: Int,
        originalWidth: Int,
        originalHeight: Int
    ): File = withContext(Dispatchers.IO) {

        val bitmap = Bitmap.createBitmap(outputWidth, outputHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)

        val scaleX = outputWidth.toFloat() / originalWidth
        val scaleY = outputHeight.toFloat() / originalHeight

        for (spec in textSpecs) {
            drawSingleTextLine(context, canvas, spec, scaleX, scaleY)
        }

        val outFile = File(context.filesDir, outputName)
        outFile.outputStream().use { stream ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
        }

        return@withContext outFile
    }

    private suspend fun drawSingleTextLine(
        context: Context,
        canvas: Canvas,
        spec: TextLineSpec,
        scaleX: Float,
        scaleY: Float
    ) {
        val typeface = try {
            FontDownloader.getGoogleFont(context, spec.googleFontName)
        } catch (e: Exception) {
            e.printStackTrace()
            Typeface.DEFAULT
        }

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = spec.color
            textSize = spec.fontSizePx * scaleY
            style = Paint.Style.FILL
            this.typeface = typeface
        }

        val bbox = spec.bbox
        val left = bbox[0].first * scaleX
        val top = bbox[0].second * scaleY
        val bottom = bbox[2].second * scaleY

        val y = top + (bottom - top) / 2f - paint.fontMetrics.bottom
        canvas.drawText(spec.text, left, y, paint)
    }
}
